import Portfolio from "./Portfolio";
import Contact from "./Contact";
import Timeline from "./Timeline";
import Intro from "./Intro";
import Projects from "./Projects";

const Home = () => {
  return (
    <>
      <Intro />
      <Projects />
      <Portfolio />
      <Timeline />
      <Contact />
    </>
  );
};

export default Home;
